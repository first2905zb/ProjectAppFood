import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Massage = () => {
  return (
    <View>
      <Text>Massage</Text>
    </View>
  )
}

export default Massage

const styles = StyleSheet.create({})