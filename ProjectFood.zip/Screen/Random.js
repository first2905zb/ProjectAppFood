import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, FlatList } from 'react-native';

const RandomFoodScreen = ({navigation}) => {
  const [randomFood, setRandomFood] = useState({ name: '', image: require('../assets/ran.png') });
  const [nearbyRestaurants, setNearbyRestaurants] = useState([]);

  const foodList = [
    { name: 'ข้าวผัด', image: require('../assets/food1.jpg') },
    { name: 'ผัดไทย', image: require('../assets/food2.jpg') },
    { name: 'ข้าวหน้าเป็ด', image: require('../assets/food3.jpg') },
    { name: 'ก๋วยเตี๋ยว', image: require('../assets/food4.jpg') },
    { name: 'ส้มตำ', image: require('../assets/food5.jpg') },
    { name: 'ข้าวมันไก่', image: require('../assets/food1.jpg') },
    { name: 'ปิ้งย่าง', image: require('../assets/food2.jpg') },
    { name: 'หมูกระทะ', image: require('../assets/food3.jpg') }
  ];

  const nearbyRestaurantsList = [
    { name: 'ร้านอาหาร C', image: require('../assets/popular.jpeg') },
    { name: 'ร้านอาหาร D', image: require('../assets/profile.jpg') },
    { name: 'ร้านอาหาร E', image: require('../assets/profile.jpg') },
    { name: 'ร้านอาหาร F', image: require('../assets/popular.jpeg') },
    { name: 'ร้านอาหาร G', image: require('../assets/profile.jpg') }
  ];

  const randomFoodHandler = () => {
    const randomIndex = Math.floor(Math.random() * foodList.length);
    const randomFoodItem = foodList[randomIndex];
    setRandomFood(randomFoodItem);

    // Update nearby restaurants
    const shuffledRestaurants = [...nearbyRestaurantsList].sort(() => 0.5 - Math.random());
    setNearbyRestaurants(shuffledRestaurants.slice(0, 3));
  };

  return (
    <View style={styles.container}>
      <View style={styles.contentContainer}>
        <Text style={styles.title}>สุ่มเมนูอาหาร</Text>
        <TouchableOpacity style={styles.randomFoodContainer} onPress={randomFoodHandler}>
          <Image source={randomFood.image} style={styles.foodImage} />
          <View style={styles.randomFoodOverlay}>
            <Text style={styles.randomFoodText}>{randomFood.name}</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.nearbyRestaurantsContainer}>
        <Text style={styles.nearbyRestaurantsTitle}>ร้านอาหารใกล้เคียง</Text>
        <FlatList
          data={nearbyRestaurants}
          horizontal
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.nearbyRestaurantContainer} onPress={() => navigation.navigate("Finrandom")}>
              <Image source={item.image} style={styles.nearbyRestaurantImage} />
              <Text style={styles.nearbyRestaurantName}>{item.name}</Text>
            </TouchableOpacity>
          )}
          keyExtractor={(item, index) => index.toString()}
          contentContainerStyle={styles.nearbyRestaurantsList}
        />
      </View>
      <TouchableOpacity style={styles.randomButton} onPress={randomFoodHandler}>
        <Text style={styles.buttonText}>สุ่มเมนูอาหารใหม่</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f7f7',
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 20,
  },
  contentContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  randomFoodContainer: {
    position: 'relative',
    width: '100%',
    height: 300,
    marginBottom: 20,
  },
  randomFoodOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  randomFoodText: {
    fontSize: 20,
    textAlign: 'center',
    color: '#fff',
  },
  foodImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    borderRadius: 20,
  },
  nearbyRestaurantsContainer: {
    marginBottom: 20,
  },
  nearbyRestaurantsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  nearbyRestaurantContainer: {
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    overflow: 'hidden',
    width: 150,
    height: 150,
  },
  nearbyRestaurantImage: {
    width: '100%',
    height: 100,
    resizeMode: 'cover',
  },
  nearbyRestaurantName: {
    paddingVertical: 5,
    color: '#555',
    fontSize: 16,
    textAlign: 'center',
  },
  randomButton: {
    backgroundColor: '#007bff',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 25,
    marginBottom: 20,
    alignSelf: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default RandomFoodScreen;
